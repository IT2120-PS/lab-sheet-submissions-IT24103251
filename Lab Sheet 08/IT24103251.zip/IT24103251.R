# Read the nicotine data
nicotine_data <- read.table("Data - Lab 8.txt", header = TRUE)
nicotine <- nicotine_data$Nicotine

# Calculate population mean
pop_mean <- mean(nicotine)
print(paste("Population Mean:", pop_mean))

# Calculate population variance
pop_variance <- var(nicotine) * (length(nicotine) - 1) / length(nicotine)
print(paste("Population Variance:", pop_variance))

# Set seed for reproducibility
set.seed(123)

# Create empty vectors to store results
sample_means <- numeric(30)
sample_variances <- numeric(30)

# Take 30 samples of size 5
for(i in 1:30) {
  sample_data <- sample(nicotine, size = 5, replace = TRUE)
  sample_means[i] <- mean(sample_data)
  sample_variances[i] <- var(sample_data)
}

# Display the results
print("Sample Means:")
print(sample_means)
print("Sample Variances:")
print(sample_variances)
# Calculate mean of sample means
mean_of_sample_means <- mean(sample_means)
print(paste("Mean of Sample Means:", mean_of_sample_means))

# Calculate variance of sample means
variance_of_sample_means <- var(sample_means)
print(paste("Variance of Sample Means:", variance_of_sample_means))

