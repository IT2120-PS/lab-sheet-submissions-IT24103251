# Problem 1: Uniform distribution (train arrival)
# The train can arrive anywhere from 0 to 40 minutes after 8:00
# We want P(10 < X < 25)

prob1 <- punif(25, min=0, max=40) - punif(10, min=0, max=40)
prob1
# Problem 2: Exponential distribution (software update)
# Lambda = 1/3, we want P(X <= 2)

prob2 <- pexp(2, rate=1/3)
prob2
# Problem 3i: Normal distribution (IQ scores)
# Mean = 100, SD = 15
# We want P(X > 130)

prob3i <- 1 - pnorm(130, mean=100, sd=15)
prob3i
# Problem 3ii: Find the IQ at 95th percentile

iq_95th <- qnorm(0.95, mean=100, sd=15)
iq_95th
