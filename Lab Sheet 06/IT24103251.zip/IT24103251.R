# Question 1(i) - What distribution?
# Answer: Binomial distribution with n=44, p=0.92

# Question 1(ii) - Probability that EXACTLY 40 are cured
dbinom(40, size=44, prob=0.92)

# Question 1(iii) - Probability that 35 or LESS are cured
pbinom(35, size=44, prob=0.92)

# Question 1(iv) - Probability that AT LEAST 38 are cured
# "At least 38" means 38 or more
pbinom(37, size=44, prob=0.92, lower.tail=FALSE)
# OR you can do: 1 - pbinom(37, size=44, prob=0.92)

# Question 1(v) - Probability between 40 and 42 (including both)
pbinom(42, size=44, prob=0.92) - pbinom(39, size=44, prob=0.92)
# Question 2(i) - Random variable X = number of babies born per day

# Question 2(ii) - Distribution?
# Answer: Poisson distribution with lambda=5

# Question 2(iii) - Probability of EXACTLY 6 babies tomorrow
dpois(6, lambda=5)

# Question 2(iv) - Probability of MORE THAN 6 babies
# "More than 6" means 7, 8, 9, ...
ppois(6, lambda=5, lower.tail=FALSE)
# OR: 1 - ppois(6, lambda=5)
# Question 1(i) - Distribution?
# Answer: Binomial distribution with n=50, p=0.85

# Question 1(ii) - Probability at least 47 passed
# "At least 47" means 47, 48, 49, or 50 students
pbinom(46, size=50, prob=0.85, lower.tail=FALSE)
# OR: 1 - pbinom(46, size=50, prob=0.85)
# Question 2(i) - Random variable X = number of calls per hour

# Question 2(ii) - Distribution?
# Answer: Poisson distribution with lambda=12

# Question 2(iii) - Probability of exactly 15 calls
dpois(15, lambda=12)